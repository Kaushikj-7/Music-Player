#!/bin/bash
cd "$(dirname "$0")"
./music_player "$@"
